﻿using Domain.Agregate.Persistances;
using $safeprojectname$.Persistances;
using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$;

public static class DefaultInfrastructureModule
{
    public static void AddInfrastructureLayer(this IServiceCollection services)
    {
        services.AddScoped<IPersistWeatherForcast, WeatherForcastRepository>();
    }
}
