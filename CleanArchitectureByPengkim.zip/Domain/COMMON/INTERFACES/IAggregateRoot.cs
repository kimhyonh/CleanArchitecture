﻿namespace $safeprojectname$.Common.Interfaces;

public interface IAggregateRoot
{
}
