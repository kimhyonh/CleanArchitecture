using $safeprojectname$.Agregate.Models;
using $safeprojectname$.Common;
using $safeprojectname$.Common.Interfaces;

namespace $safeprojectname$.Models;

public class WeatherForecast : Entity<Guid>, IAggregateRoot
{
    public WeatherForecast(Guid id) 
        : base(id)
    {
    }

    public DateTime Date { get; set; }

    public Temporature Temporature { get; set; } = Temporature.WaterFreezed;

    public string? Summary { get; set; }
}