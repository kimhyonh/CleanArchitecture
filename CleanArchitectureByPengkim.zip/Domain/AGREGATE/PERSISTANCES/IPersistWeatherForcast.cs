﻿using $safeprojectname$.Common.Interfaces;
using $safeprojectname$.Models;

namespace $safeprojectname$.Agregate.Persistances;

public interface IPersistWeatherForcast : IRepository<WeatherForecast>
{
    /**
     * Using this interface to provide 'WeatherForecast' specific 
     * persistance methods.
     */
}
